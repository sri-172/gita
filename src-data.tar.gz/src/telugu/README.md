# Telugu corpus

Downloaded from https://github.com/nvkudva/Bhagavad-Geeta (files
`src/data/verses.json` and `src/data/chapters.json`).

That project states: "The Telugu translations are imported from te.wikisource
under CC BY-SA 4.0"; the Telugu-script shlokas, Telugu translations and Telugu
chapter metadata come from te.wikisource.org — భగవద్గీత తెలుగు అనువాదము.
The Telugu `commentary_telugu` field is a machine translation (IndicTrans2,
ai4bharat) of an English commentary, as recorded by
`commentary_telugu_source` in verses.json.

Upstream repository README says "No licence file yet — all rights reserved"
for its own code/compilation; the underlying Wikisource text is CC BY-SA 4.0.
Attribution is shown in the site footer and in README.md.

Coverage: 701/701 Telugu-script shlokas, 701/701 Telugu translations,
695/701 Telugu commentaries, 22/701 Telugu context notes, 18/18 Telugu
chapter names, meanings and summaries.
